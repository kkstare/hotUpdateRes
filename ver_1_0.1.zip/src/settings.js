window._CCSettings = {
    platform: "android",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: false,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/scenes/main.fire",
    orientation: "",
    server: "",
    debug: true,
    jsList: []
};
